package com.ge.www;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerSrv extends HttpServlet{
	
	protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		//reading form1 data
		String uname=req.getParameter("username");
		String pass=req.getParameter("password");
		String cpass=req.getParameter("cpassword");
		
		
		RegisterBean bean=new RegisterBean();
		bean.setUsername(uname);
		bean.setPassword(pass);
		bean.setCpassword(cpass);
		
		req.setAttribute("bean",bean);
		Connection con=null;
		PreparedStatement ps=null;
		int result=0;
		String qry=null;
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","admin");

			qry="insert into reges values(?,?,?)";
			
			ps=con.prepareStatement(qry);
			
			ps.setString(1,bean.getUsername());
			ps.setString(2,bean.getPassword());
			ps.setString(3,bean.getCpassword());
			
			result=ps.executeUpdate();
			if(result==0)
			{
				pw.println("No record inserted");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("mainpage3.jsp");
				rd.forward(req,res);
			}
				
			ps.close();
			con.close();
		
		}
		catch(Exception e)
		{
				pw.println("Sorry! Exception occured");
		}
		
		
		pw.close();
		
	}

}











